# vue-music-rest-api

This is the back-end rest-api for my [vue-js music](https://github.com/nouaryk/vue-music) webapp.

Built in nodejs and mongodb (mongoose)