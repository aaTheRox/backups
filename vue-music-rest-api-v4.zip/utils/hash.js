export utils = {
    const hash = () => {
        console.log('test')
    }
}